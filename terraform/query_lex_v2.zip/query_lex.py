import boto3
import json
import os
import datetime
from boto3.dynamodb.conditions import Key, Attr
from decimal import Decimal
import openai
import calendar
os.environ['OPENAI_API_KEY'] = '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'

# Helper class to handle Decimal serialization
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))  # Log the incoming event
    
    # Check if this is a direct invocation from Lex
    if 'sessionState' in event:
        return handle_lex_invocation(event, context)
    # Otherwise, assume it's coming from API Gateway
    else:
        return handle_api_gateway_request(event, context)

def handle_lex_invocation(event, context):
    try:
        # Extract intent name
        intent_name = event['sessionState']['intent']['name']
        print(f"Handling intent: {intent_name}")
        
        # Route to appropriate handler based on intent
        
        if intent_name == 'GetSpendingByCategory':
            return handle_get_spending_by_category(event)
        elif intent_name == 'TransactionSearch':
            return handle_transaction_search(event)
        elif intent_name == 'MonthlySummary':
            return handle_monthly_summary(event)
        else:
            # Default handler
            return {
                "sessionState": {
                    "dialogAction": {
                        "type": "Close"
                    },
                    "intent": {
                        "name": intent_name,
                        "state": "Fulfilled"
                    }
                },
                "messages": [
                    {
                        "contentType": "PlainText",
                        "content": f"I'm not sure how to handle the {intent_name} intent yet."
                    }
                ]
            }
    except Exception as e:
        print(f"Error in Lex invocation: {str(e)}")
        # Return a properly formatted Lex response even for errors
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": event['sessionState']['intent']['name'],
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": f"I'm sorry, I encountered an error: {str(e)}"
                }
            ]
        }
    
def handle_recent_transactions(event):
    """
    Handle the GetRecentTransactions intent
    """
    try:
        # Extract intent name and slot information
        intent_name = event['sessionState']['intent']['name']
        slots = event['sessionState']['intent'].get('slots', {})
        
        # Get the number of transactions requested
        num_transactions = 5  # Default value
        if slots and slots.get('NumberOfTransactions') and slots['NumberOfTransactions'].get('value'):
            num_transactions = slots['NumberOfTransactions']['value']['interpretedValue']
        
        # Get transactions from DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('Transactions')
        
        # Scan the table to get all transactions
        response = table.scan()
        transactions = response.get('Items', [])
        
        # Continue scanning if we have more items (pagination)
        while 'LastEvaluatedKey' in response:
            response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            transactions.extend(response.get('Items', []))
            
        print(f"Retrieved total of {len(transactions)} transactions")
        
        # Sort by date in descending order (newest first)
        sorted_transactions = sorted(
            transactions,
            key=lambda x: x.get('date', '0000-00-00'),
            reverse=True  # True for descending order (newest first)
        )
        
        # Take only the requested number
        latest_transactions = sorted_transactions[:int(num_transactions)]
        
        if not latest_transactions:
            message_content = f"I couldn't find any recent transactions in your account."
        else:
            # Format transactions using your table's structure
            message_content = f"Here are your last {len(latest_transactions)} transactions:\n"
            for i, tx in enumerate(latest_transactions, 1):
                date = tx.get('date', 'Unknown date')
                amount = tx.get('amount', 'Unknown amount')
                merchant = tx.get('merchant_name', tx.get('name', 'Unknown merchant'))
                
                message_content += f"{i}. {date}: ${amount} - {merchant}\n"
        
        # Build Lex response
        response = {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": intent_name,
                    "state": "Fulfilled"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": message_content
                }
            ]
        }
        
        return response
        
    except Exception as e:
        print(f"Error in handle_recent_transactions: {str(e)}")
        # Return a properly formatted Lex response even for errors
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": event['sessionState']['intent']['name'],
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": f"I'm sorry, I encountered an error: {str(e)}"
                }
            ]
        }
    
# ————— Your helpers —————
def generate_spending_summary(user_question: str, transactions: list) -> str:
    """
    Given the user's original question and a list of DynamoDB items (transactions),
    ask GPT‑4o to summarize total spending and highlight any large transactions.
    Returns the assistant’s reply as a plain string.
    """
    prompt = (
        f"You are a banking assistant. The user asked:\n> {user_question}\n\n"
        f"Here are the transactions:\n{json.dumps(transactions, indent=2)}\n\n"
        "Please summarize how much was spent in total, and mention the single largest charge."
    )

    resp = openai.ChatCompletion.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}]
    )
    # Pull out the assistant’s reply
    return resp.choices[0].message.content.strip()

def _by_category(category, period):
    # period → date‐range logic can still live here if you want,
    # otherwise ignore `period` entirely and just filter on category.
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Cleaned_Transactions')
    return table.scan(
        FilterExpression=Attr("category").eq(category)
    )["Items"]

def _search(merchant: str, amount: float = None, comparator: str = "gte") -> list:
    """
    Scan Cleaned_Transactions for records whose merchant_name contains `merchant`
    and whose amount is >= or <= `amount` depending on `comparator`.
    """
    # Base filter on merchant
    fe = Attr("merchant_name").contains(merchant)

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Cleaned_Transactions')

    # Add amount filter if provided
    if amount is not None:
        if comparator == "gte":
            amt_filter = Attr("amount").gte(Decimal(str(amount)))
        else:  # "lte"
            amt_filter = Attr("amount").lte(Decimal(str(amount)))
        fe = fe & amt_filter

    return table.scan(FilterExpression=fe)["Items"]

def _monthly(month: int, year: int) -> list:
    """
    Returns all items whose 'date' field is between the first
    and last day of the given month/year.
    """
    # YYYY‑MM‑01
    start_date = f"{year:04d}-{month:02d}-01"
    # last day of month
    last_day = calendar.monthrange(year, month)[1]
    end_date = f"{year:04d}-{month:02d}-{last_day:02d}"
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Cleaned_Transactions')
    resp = table.scan(
        FilterExpression=Attr("date").between(start_date, end_date)
    )
    return resp.get("Items", [])

# ————— New intent handler —————
def handle_get_spending_by_category(event, context=None):
    # 1. Pull your slots
    slots   = event["sessionState"]["intent"]["slots"] or {}
    category = slots.get("Category", {}).get("value", {}).get("interpretedValue", "").lower()
    period   = slots.get("TimePeriod", {}).get("value", {}).get("interpretedValue", "").lower()

    # 2. If missing, elicit
    if not category or not period:
        missing = "Category" if not category else "TimePeriod"
        return {
            "sessionState": {
                "dialogAction": {"type": "ElicitSlot", "slotToElicit": missing},
                "intent": {"name": event["sessionState"]["intent"]["name"], "slots": slots}
            }
        }

    # 3. Fetch just by category
    transactions = _by_category(category, period)
    
    # 4. Grab raw user text
    user_question = event.get("inputTranscript", "").strip()

    # 5. Delegate to our helper
    answer = generate_spending_summary(user_question, transactions)

    # 6. Return to Lex
    return {
        "sessionState": {
            "dialogAction": {"type": "Close"},
            "intent": {"name": event["sessionState"]["intent"]["name"], "state": "Fulfilled"}
        },
        "messages": [{
            "contentType": "PlainText",
            "content": answer
        }]
    }

# ————— TransactionSearch intent handler —————
def handle_transaction_search(event, context=None):
    slots = event["sessionState"]["intent"].get("slots", {}) or {}

    # 1. Pull merchant and numeric amount
    merchant = slots.get("Merchant", {})\
                   .get("value", {})\
                   .get("interpretedValue", "")\
                   .lower()
    amt_str = slots.get("MinAmount", {})\
                    .get("value", {})\
                    .get("interpretedValue", "")
    amount = float(amt_str) if amt_str else None

    # 2. If we don’t know merchant yet, ask for it
    if not merchant:
        return {
            "sessionState": {
                "dialogAction": {"type": "ElicitSlot", "slotToElicit": "Merchant"},
                "intent": {"name": event["sessionState"]["intent"]["name"], "slots": slots}
            }
        }

    # 3. Figure out comparator from the raw text
    text = event.get("inputTranscript", "").lower()
    if any(kw in text for kw in ["less than", "smaller than", "under", "below"]):
        comparator = "lte"
    else:
        comparator = "gte"

    # 4. Fetch matching items
    transactions = _search(merchant, amount, comparator)

    # 5. Grab exactly what the user said
    user_question = event.get("inputTranscript", "").strip()

    # 6. Send to GPT‑4o for a neat summary
    answer = generate_spending_summary(user_question, transactions)

    # 7. Return it to Lex
    return {
        "sessionState": {
            "dialogAction": {"type": "Close"},
            "intent": {
                "name": event["sessionState"]["intent"]["name"],
                "state": "Fulfilled"
            }
        },
        "messages": [{
            "contentType": "PlainText",
            "content": answer
        }]
    }

def handle_monthly_summary(event, context=None):
    slots = event["sessionState"]["intent"].get("slots", {}) or {}

    # 1. Extract raw slot values
    month_val = slots.get("Month", {}) \
                     .get("value", {}) \
                     .get("interpretedValue", "")
    year_val  = slots.get("Year",  {}) \
                     .get("value", {}) \
                     .get("interpretedValue", "")

    # 2. Elicit missing slot
    if not month_val or not year_val:
        missing = "Month" if not month_val else "Year"
        return {
            "sessionState": {
                "dialogAction": {"type": "ElicitSlot", "slotToElicit": missing},
                "intent": {"name": event["sessionState"]["intent"]["name"], "slots": slots}
            }
        }

    # 3. Parse month (name or number) and year
    try:
        month = int(month_val)
    except ValueError:
        month = {n.lower(): i for i, n in enumerate(calendar.month_name) if n}[month_val.lower()]
    year = int(year_val)

    # 4. Fetch that month’s transactions
    transactions = _monthly(month, year)

    # 5. Grab the exact user text
    user_question = event.get("inputTranscript", "").strip()

    # 6. Summarize via your existing helper
    answer = generate_spending_summary(user_question, transactions)

    # 7. Return Lex‑formatted response
    return {
        "sessionState": {
            "dialogAction": {"type": "Close"},
            "intent": {
                "name": event["sessionState"]["intent"]["name"],
                "state": "Fulfilled"
            }
        },
        "messages": [{
            "contentType": "PlainText",
            "content": answer
        }]
    }

def handle_api_gateway_request(event, context):
    lex_client = boto3.client('lexv2-runtime')
    
    try:
        # Parse the body from the event
        body = json.loads(event.get('body', '{}'))
        user_message = body.get('message', '')
        
        if not user_message:
            raise ValueError("No message provided in the request body.")
        
        # Extract user ID from the request context (if available)
        user_id = event.get('requestContext', {}).get('authorizer', {}).get('claims', {}).get('sub', 'anonymous')
        
        # Call Lex to get a response based on the user input
        response = lex_client.recognize_text(
            botId=os.environ['LEX_BOT_ID'],
            botAliasId=os.environ['LEX_BOT_ALIAS_ID'],
            localeId='en_US',
            sessionId=user_id,
            text=user_message
        )
        
        # Add logs for Lex response
        print("Lex response:", json.dumps(response, cls=DecimalEncoder))
        
        # Ensure the 'messages' field exists before accessing it
        messages = response.get('messages', [])
        if messages:
            bot_response = messages[0].get('content', "I'm sorry, I couldn't process that request.")
        else:
            bot_response = "I'm sorry, I couldn't process that request."
        
        # Return the processed response
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'message': bot_response,
                'sessionState': response.get('sessionState', {}),
                'requestAttributes': response.get('requestAttributes', {})
            }, cls=DecimalEncoder)
        }
        
    except ValueError as ve:
        print(f"ValueError: {str(ve)}")
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': f"Bad request: {str(ve)}"
            })
        }
    
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': f"Internal server error: {str(e)}"
            })
        }